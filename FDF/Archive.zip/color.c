/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   color.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgrass <mgrass@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/13 12:42:53 by mgrass            #+#    #+#             */
/*   Updated: 2019/11/14 15:19:21 by mgrass           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

# define ABS(a) ((a > 0) ? a : -a)

double percent(int start, int end, int current)
{
	double placement;
	double distance;

	placement = current - start;
	//printf("pl %f\n", placement);
	distance = end - start;
	//printf("dis %f\n", distance);
	return ((distance == 0) ? 1.0 : (placement / distance));
}

int get_light(int start, int end, double percentage)
{
	return ((int)((1 - percentage) * start + percentage * end));
}

// int get_color(int x, int y, t_bres *point)
int get_color(t_bres *point)
{
	int     red;
	int     green;
	int     blue;
	double  percentage;
	
	int x = point->x_start;
	int y = point->y_start;
	// printf("x %d\n", point->x_start);
    // printf("y %d\n", point->y_start);
	int dx = ABS(point->end_x - point->x_start);
	int dy = ABS(point->end_y - point->y_start);

	int end_x = point->x_start + 1;
	int end_y = point->y_start + 1;


	if (point->color_st == point->color_end)
		return (point->color_st);
		
	// printf("x y %d %d\n", point->dx1, point->dy1);
	// printf("x y %d %d\n", dx, dy);
	// if (point->dx1 > point->dy1) //(delta.x > delta.y)
	if (dx > dy)
	{
		// percentage = percent(point->x_start, point->x_end, x); //x должен быть равен x_start
		
		percentage = percent(point->x_start, end_x, x);

		// printf("cent %f\n", percentage);
		// printf("st en x %d %d %d\n", point->x_start, point->x_end, x);
		// printf("color: %d\n", point->color_st);
		// printf("color: %d\n", point->color_end);
	}
	else
	{
		// percentage = percent(point->y_start, point->y_end, y); //y должен быть равен y_start
		
		percentage = percent(point->y_start, end_y, y);

		// printf("cent %f\n", percentage);
		// printf("st en y %d %d %d\n", point->y_start, point->y_end, y);
		// printf("color else: %d\n", point->color_st);
		// printf("color else: %d\n", point->color_end);
	}
	red = get_light((point->color_st >> 16) & 0xFF, (point->color_end >> 16) & 0xFF, percentage);
	green = get_light((point->color_st >> 8) & 0xFF, (point->color_end >> 8) & 0xFF, percentage);
	blue = get_light(point->color_st & 0xFF, point->color_end & 0xFF, percentage);
	return ((red << 16) | (green << 8) | blue);
}

int color_height(t_bres *point)
{
	double	percentage;
	int z;
	z = point->z_start;

	percentage = percent(point->z_start, point->z_end, z);
	if (percentage < 0.5)
		return(0xffefd5);
	else
		return (0x778899);
}